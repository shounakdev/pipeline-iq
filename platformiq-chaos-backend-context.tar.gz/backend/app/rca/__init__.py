"""Evidence-grounded RCA package."""
