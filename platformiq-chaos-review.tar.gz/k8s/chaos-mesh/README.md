# PlatformIQ Chaos Mesh setup

This package installs Chaos Mesh 2.8.3 and gives PlatformIQ a deliberately
small, namespaced permission set for `PodChaos`, `NetworkChaos`, `StressChaos`,
`HTTPChaos`, and `Workflow` resources.

## Safety model

Kubernetes enforces the hard cluster boundary:

- The PlatformIQ service account has Roles only in `platformiq-dev` and
  `platformiq-staging`; it has no ClusterRole and no production binding.
- Chaos Mesh `FilterNamespace` is enabled. Only the two explicitly annotated
  namespaces accept fault injection.
- The account may create, inspect, and delete the five approved resource types.
  It cannot update/patch experiments or access Pods, Secrets, Deployments, or
  other Kubernetes resources.
- The dashboard is authenticated and cluster-internal.

PlatformIQ must enforce request/business invariants before calling Kubernetes;
plain RBAC cannot inspect a Chaos custom resource body or coordinate concurrent
requests. The application must reject a request unless all of these are true:

1. `CHAOS_ENGINE_ENABLED` is true.
2. Environment and namespace are members of their configured allowlists, and
   the requested environment matches the namespace's configured environment.
3. The target service is in PlatformIQ's service allowlist. Generate selectors
   server-side from its immutable `app.kubernetes.io/name` label; never accept a
   raw selector from the caller.
4. Duration is present, positive, and no greater than
   `CHAOS_MAX_DURATION_SECONDS`. Write the same value to `spec.duration`.
5. Cleanup behavior is explicit. On normal completion, timeout, cancellation,
   and process recovery, delete the Chaos resource and wait for recovery.
6. A database transaction/unique partial index permits at most one active run
   for `(environment, service)` and no more than
   `CHAOS_MAX_CONCURRENT_RUNS` globally for that scope.
7. The authenticated operator ID is stored in the audit record and in the
   resource annotation `platformiq.io/operator` (never trust a client-supplied
   operator value).
8. A persisted deadline is set at `started_at + duration`. A watchdog deletes
   overdue resources, marks the run `aborted`, and records the cleanup result.

A useful unique index for PostgreSQL is:

```sql
CREATE UNIQUE INDEX one_active_chaos_run_per_target
ON chaos_runs (environment, service)
WHERE status IN ('starting', 'running', 'cleaning_up');
```

Creating the database row and claiming the uniqueness constraint must happen
before the Kubernetes create call. If Kubernetes creation fails, mark the row
failed. On restart, reconcile all active rows against Kubernetes so deadlines
cannot be bypassed by a PlatformIQ process restart.

## Install

Prerequisites: Kubernetes, Helm 3, `kubectl`, cluster-admin installation rights,
and existing `platformiq-dev` / `platformiq-staging` namespaces.

First label the cluster after manually confirming its identity. This is a
one-time guard against installing into the wrong context:

```bash
kubectl --context <dev-context> label namespace kube-system \
  platformiq.io/environment=development
```

Then run:

```bash
export KUBE_CONTEXT=<dev-context>
export CHAOS_TARGET_ENVIRONMENT=development
./k8s/chaos-mesh/installation/install.sh
```

The service account disables automatic token mounting. For an in-cluster
PlatformIQ workload, create an equivalent account in the application's
namespace, update both RoleBindings, and mount an explicit projected
`serviceAccountToken` volume with a short expiry. For an external PlatformIQ
process, use a short-lived TokenRequest token through your secret
manager/identity broker and rotate it automatically. Do not create a legacy
long-lived service-account token Secret.

## Verify and access the dashboard

Run all controller, dashboard, CRD, connectivity, and positive/negative RBAC
checks again with:

```bash
KUBE_CONTEXT=<dev-context> ./k8s/chaos-mesh/installation/verify.sh
```

Use a local authenticated tunnel for the dashboard:

```bash
kubectl --context <dev-context> -n chaos-mesh \
  port-forward service/chaos-dashboard 2333:2333
```

## Required PlatformIQ tests

Add these at the service boundary using a fake Kubernetes client, plus one
cluster integration test using the real service account:

| Test | Expected result |
|---|---|
| environment=`production` | rejected before Kubernetes call |
| namespace outside configured allowlist | rejected before Kubernetes call |
| missing/zero/over-limit duration | rejected before Kubernetes call |
| second active run for same environment/service | database conflict; no Kubernetes call |
| allowed request | approved CR created with duration and operator annotation |
| deadline exceeded | CR deleted, recovery awaited, run marked aborted |
| connectivity | list approved CR type succeeds; list Pods fails |

The included `verify.sh` supplies the live connectivity and namespace-isolation
tests. It obtains a ten-minute TokenRequest credential, lists `PodChaos`, and
confirms the same credential cannot list Pods. Application unit tests must be
implemented in PlatformIQ's language and test framework; this repository does
not contain that application code.
