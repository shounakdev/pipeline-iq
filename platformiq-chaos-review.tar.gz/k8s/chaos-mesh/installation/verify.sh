#!/usr/bin/env bash
set -euo pipefail

readonly INSTALL_NAMESPACE="chaos-mesh"
readonly SERVICE_ACCOUNT="system:serviceaccount:chaos-mesh:platformiq-chaos-runner"
: "${KUBE_CONTEXT:?Set KUBE_CONTEXT to the exact development or staging kubectl context}"

k() {
  kubectl --context "${KUBE_CONTEXT}" "$@"
}

echo "Waiting for Chaos Mesh controller, daemon, and dashboard..."
k -n "${INSTALL_NAMESPACE}" rollout status deployment/chaos-controller-manager --timeout=5m
k -n "${INSTALL_NAMESPACE}" rollout status daemonset/chaos-daemon --timeout=5m
k -n "${INSTALL_NAMESPACE}" rollout status deployment/chaos-dashboard --timeout=5m

echo "Checking dashboard Service and ready endpoints..."
k -n "${INSTALL_NAMESPACE}" get service chaos-dashboard
ready_addresses="$(k -n "${INSTALL_NAMESPACE}" get endpoints chaos-dashboard -o jsonpath='{.subsets[*].addresses[*].ip}')"
if [[ -z "${ready_addresses}" ]]; then
  echo "Chaos Dashboard has no ready endpoints." >&2
  exit 1
fi

echo "Checking required CRDs..."
for crd in \
  podchaos.chaos-mesh.org \
  networkchaos.chaos-mesh.org \
  stresschaos.chaos-mesh.org \
  httpchaos.chaos-mesh.org \
  workflows.chaos-mesh.org; do
  k get crd "${crd}" >/dev/null
done

echo "Checking allowed permissions..."
for namespace in platformiq-dev platformiq-staging; do
  for resource in podchaos networkchaos stresschaos httpchaos workflows; do
    for verb in create get list watch delete; do
      answer="$(k auth can-i "${verb}" "${resource}.chaos-mesh.org" --namespace "${namespace}" --as "${SERVICE_ACCOUNT}")"
      [[ "${answer}" == "yes" ]] || {
        echo "Missing permission: ${verb} ${resource} in ${namespace}" >&2
        exit 1
      }
    done
  done
done

echo "Checking production and arbitrary namespaces are blocked..."
for namespace in platformiq-production platformiq-prod default; do
  answer="$(k auth can-i create podchaos.chaos-mesh.org --namespace "${namespace}" --as "${SERVICE_ACCOUNT}" || true)"
  [[ "${answer}" == "no" ]] || {
    echo "Unsafe permission: PlatformIQ can create PodChaos in ${namespace}" >&2
    exit 1
  }
done

echo "Checking restricted operations remain blocked..."
for namespace in platformiq-dev platformiq-staging; do
  for verb in update patch; do
    answer="$(k auth can-i "${verb}" podchaos.chaos-mesh.org --namespace "${namespace}" --as "${SERVICE_ACCOUNT}" || true)"
    [[ "${answer}" == "no" ]] || {
      echo "Unsafe permission: PlatformIQ can ${verb} PodChaos in ${namespace}" >&2
      exit 1
    }
  done
done

echo "Checking the service account with a short-lived TokenRequest credential..."
token="$(k -n "${INSTALL_NAMESPACE}" create token platformiq-chaos-runner --duration=10m)"

token_user="$(
  k create -f - -o jsonpath='{.status.user.username}' <<EOF
apiVersion: authentication.k8s.io/v1
kind: TokenReview
spec:
  token: "${token}"
EOF
)"

[[ "${token_user}" == "${SERVICE_ACCOUNT}" ]] || {
  echo "Token authenticated as '${token_user}', expected '${SERVICE_ACCOUNT}'." >&2
  exit 1
}

answer="$(k auth can-i list pods --namespace platformiq-dev --as "${SERVICE_ACCOUNT}" || true)"
[[ "${answer}" == "no" ]] || {
  echo "Unsafe permission: PlatformIQ service account can list Pods." >&2
  exit 1
}

echo "Chaos Mesh health, API discovery, and PlatformIQ RBAC checks passed."
