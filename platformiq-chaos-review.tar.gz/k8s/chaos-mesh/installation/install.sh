#!/usr/bin/env bash
set -euo pipefail

readonly CHART_VERSION="2.8.3"
readonly RELEASE_NAME="chaos-mesh"
readonly INSTALL_NAMESPACE="chaos-mesh"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly MANIFEST_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

: "${KUBE_CONTEXT:?Set KUBE_CONTEXT to the exact development or staging kubectl context}"
: "${CHAOS_TARGET_ENVIRONMENT:?Set CHAOS_TARGET_ENVIRONMENT to development or staging}"

case "${CHAOS_TARGET_ENVIRONMENT}" in
  development|staging) ;;
  *)
    echo "Refusing installation: CHAOS_TARGET_ENVIRONMENT must be development or staging." >&2
    exit 1
    ;;
esac

if ! kubectl config get-contexts "${KUBE_CONTEXT}" >/dev/null 2>&1; then
  echo "kubectl context does not exist: ${KUBE_CONTEXT}" >&2
  exit 1
fi

current_context="$(kubectl config current-context)"
if [[ "${current_context}" != "${KUBE_CONTEXT}" ]]; then
  echo "Refusing installation: current context '${current_context}' is not KUBE_CONTEXT '${KUBE_CONTEXT}'." >&2
  exit 1
fi

# A human must label kube-system once after verifying the cluster identity:
# kubectl label namespace kube-system platformiq.io/environment=development
cluster_environment="$(kubectl --context "${KUBE_CONTEXT}" get namespace kube-system -o jsonpath='{.metadata.labels.platformiq\.io/environment}')"
if [[ "${cluster_environment}" != "${CHAOS_TARGET_ENVIRONMENT}" ]]; then
  echo "Refusing installation: kube-system is labeled '${cluster_environment:-<unset>}', expected '${CHAOS_TARGET_ENVIRONMENT}'." >&2
  exit 1
fi

kubectl --context "${KUBE_CONTEXT}" apply -f "${MANIFEST_DIR}/namespace.yaml"
kubectl --context "${KUBE_CONTEXT}" apply -f "${SCRIPT_DIR}/allowed-namespaces.yaml"

helm repo add chaos-mesh https://charts.chaos-mesh.org
helm repo update chaos-mesh
helm upgrade --install "${RELEASE_NAME}" chaos-mesh/chaos-mesh \
  --kube-context "${KUBE_CONTEXT}" \
  --namespace "${INSTALL_NAMESPACE}" \
  --version "${CHART_VERSION}" \
  --values "${SCRIPT_DIR}/values.yaml" \
  --wait \
  --timeout 10m

kubectl --context "${KUBE_CONTEXT}" apply -f "${MANIFEST_DIR}/service-account.yaml"
kubectl --context "${KUBE_CONTEXT}" apply -f "${MANIFEST_DIR}/role.yaml"
kubectl --context "${KUBE_CONTEXT}" apply -f "${MANIFEST_DIR}/role-binding.yaml"

"${SCRIPT_DIR}/verify.sh"

